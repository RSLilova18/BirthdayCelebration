package Interfaces;

public interface Birthable {
    public String getBirthDate();
}
