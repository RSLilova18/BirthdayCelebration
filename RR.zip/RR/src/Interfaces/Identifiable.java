package Interfaces;

public interface Identifiable {
    public String getId();
}
